from django.shortcuts import render,render_to_response,get_object_or_404
from .models import BlogType,Blog

def get_public_common_date(request,blog_all_list):
    pass

def blog_list(request):
    context ={}
    context['blogs'] = Blog.objects.all().count()
    context['blog_types'] = BlogType.objects.all()
    context['blog_dates'] = Blog.objects.dates('created_time','month', order="DESC")
    return render_to_response('blog/blog_list.html',context)

def blog_detail(request,blog_pk):
    blog = get_object_or_404(Blog, pk=blog_pk)
    context = {}
    context['blog'] = blog

    return render_to_response('blog/templates/blog_detail.html', context)

def blog_type(request,type_pk):
    context = {}
    return render_to_response('blog/templates/blog_type.html', context)

def blog_date(request,year,month):
    context = {}
    return render_to_response('blog/templates/blog_date.html', context)

