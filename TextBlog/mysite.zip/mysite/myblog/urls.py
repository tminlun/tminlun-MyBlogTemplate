from django.urls import path
from . import views

urlpatterns = [
    path('', views.blog_list, name="blog_list"),
    # path('<int:type_pk>', views.blog_detail, name="blog_dateil"),
    # path('type/<int:type_pk>', views.blog_type, name="blog_type"),
    # path('date/<int:year>/<int:month>', views.blog_date, name="blog_date"),
]