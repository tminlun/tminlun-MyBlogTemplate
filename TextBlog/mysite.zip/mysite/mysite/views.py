from django.shortcuts import render_to_response,render

def home(request):
    context = {}
    return render_to_response('home.html', context)

def blog_love(request):
    context = {}
    return render_to_response('love/index.html', context)